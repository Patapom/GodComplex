﻿namespace ZetaHtmlEditControl
{
	public static class HtmlEditHelper
	{
		public static string ImagesFolderPathPlaceHolder
		{
			get
			{
				return @"http://pseudo-image-folder-path";
			}
		}
	}
}