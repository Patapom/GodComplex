namespace ZetaHtmlEditControl.Code.Configuration
{
    public sealed class TextModuleInfo
    {
        public string Name { get; set; }
        public string Html { get; set; }
    }
}